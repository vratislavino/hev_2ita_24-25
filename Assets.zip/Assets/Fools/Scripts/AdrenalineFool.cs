using UnityEngine;

public class AdrenalineFool : Fool
{

}
