using UnityEngine;

public class ClassicFool : Fool
{
    
}
